<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>S</title>
</head>
<body>


<table>

<tr><td>
    <form action="add.php" method="POST">
        Speacialist</td> <td><input type="text" placeholder="Specialist" name="spe"></td></tr>
        <tr><td> Doctor name </td><td><input type="text" placeholder="" name="docotor"><br></td></tr>
        <tr><td>Fee </td><td><input type="text" placeholder="$" name="fee"><br></td></tr>
        <tr><td>Date </td><td><input type="date" placeholder="" name="d"><br></td></tr>
        <tr><td>Time</td> <td><input type="time" placeholder="" name="t"><br></td></tr>

        <tr><td>  <input type="submit"></td></tr>
    </form>
    </table>
</body>
</html>