<?php 
session_start();

unset($_SESSION['doctor']);
unset($_SESSION['ddob']);
unset($_SESSION['dmob']);
unset($_SESSION['dadd']);
unset($_SESSION['dhosp']);



?>
<meta http-equiv="refresh" content="0; url=/hospital">