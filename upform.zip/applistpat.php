<table>
    <tr>
        <td>Specialist</td>
        <td>Docotr</td>
        <td>Fee</td>
        <td>Date</td>
        <td>Time</td>
        <td>Edit</td>
        <td>Cancel</td>
    </tr>
</table>


<style>

    table, tr,td{border:black solid 2px;
    padding:5px;}

</style>