<?php 
session_start();

unset($_SESSION['patient']);
unset($_SESSION['id']);
unset($_SESSION['pmbl']);
unset($_SESSION['padd']);
unset($_SESSION['phosp']);



?>
<meta http-equiv="refresh" content="0; url=/hospital">