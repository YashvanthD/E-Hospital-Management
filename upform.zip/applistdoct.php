<table>
    <thead>
        <td>Patient Id</td>
        <td>Patient Name</td>
        <td>Appointment id</td>
        <td>Date</td>
        <td>Time</td>
        <td>View</td>
        <td>Cancel</td>
    </thead>
    <tr>
        <td >Patient Id</td>
        <td>Patient Name</td>
        <td>Appointment id</td>
        <td>Date</td>
        <td>Time</td>
        <td>View</td>
        <td>Cancel</td>
    </tr>
</table>


<style>

    table, thead{border: 2px solid black;
    padding:5px;}
    tr{
        border:black solid 2px;
    }

</style>